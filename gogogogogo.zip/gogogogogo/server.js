const http = require("http");
const fs = require("fs");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 3000);
const HOST = "0.0.0.0";
const DB_FILE = "db.json";
const STORE_NAME = process.env.STORE_NAME || "Paozix";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
  "Access-Control-Allow-Credentials": "true"
};

function database() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch {
    const db = {
      name: STORE_NAME,
      users: [],
      products: [],
      orders: [],
      reviews: [],
      tickets: [],
      sessions: [],
      emailCodes: []
    };

    saveDatabase(db);
    return db;
  }
}

function saveDatabase(db) {
  fs.writeFileSync(
    DB_FILE,
    JSON.stringify(db, null, 2),
    "utf8"
  );
}

function makeId(prefix) {
  return (
    prefix +
    "_" +
    Date.now().toString(36) +
    "_" +
    crypto.randomBytes(5).toString("hex")
  );
}

function makeCode() {
  return String(
    crypto.randomInt(100000, 1000000)
  );
}

function json(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    ...CORS
  });

  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";

    req.on("data", chunk => {
      raw += chunk;

      if (raw.length > 2000000) {
        req.destroy();
        reject(new Error("Requisição muito grande"));
      }
    });

    req.on("end", () => {
      if (!raw) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(raw));
      } catch {
        reject(new Error("JSON inválido"));
      }
    });

    req.on("error", reject);
  });
}

function getCookies(req) {
  const result = {};

  const list = (req.headers.cookie || "").split(";");

  for (const item of list) {
    const index = item.indexOf("=");

    if (index <= 0) continue;

    const key = item
      .slice(0, index)
      .trim();

    const value = item
      .slice(index + 1)
      .trim();

    result[key] = decodeURIComponent(value);
  }

  return result;
}

function setSessionCookie(res, value, maxAge = 86400) {
  res.setHeader(
    "Set-Cookie",
    `sid=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; HttpOnly; SameSite=Lax`
  );
}

function getCurrentUser(req, db) {
  const sid = getCookies(req).sid;

  if (!sid) return null;

  const session = db.sessions.find(
    x => x.id === sid
  );

  if (!session) return null;

  return (
    db.users.find(
      x => x.id === session.userId
    ) || null
  );
}

function publicUser(user) {
  if (!user) return null;

  const copy = { ...user };

  delete copy.password;

  return copy;
}

/* =========================================================
   ENVIO DE E-MAIL
   ========================================================= */

async function sendEmail(to, subject, text) {
  const host = process.env.SMTP_HOST;
  const port = Number(
    process.env.SMTP_PORT || 587
  );
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from =
    process.env.SMTP_FROM || user;

  /*
   SMTP não configurado:
   o código aparece no Termux para teste.
  */

  if (!host || !user || !pass || !from) {
    console.log("");
    console.log("==============================");
    console.log("MODO DE TESTE DE E-MAIL");
    console.log("==============================");
    console.log("Para:", to);
    console.log("Assunto:", subject);
    console.log(text);
    console.log("==============================");
    console.log("");

    return {
      sent: false,
      test: true
    };
  }

  let nodemailer;

  try {
    nodemailer = require("nodemailer");
  } catch {
    throw new Error(
      "Nodemailer não instalado. Execute: npm install nodemailer"
    );
  }

  const transporter =
    nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: {
        user,
        pass
      }
    });

  await transporter.sendMail({
    from,
    to,
    subject,
    text
  });

  return {
    sent: true,
    test: false
  };
}

/* =========================================================
   CÓDIGO DE E-MAIL
   ========================================================= */

async function requestEmailCode(email, db) {
  const normalized = String(email || "")
    .trim()
    .toLowerCase();

  if (
    !normalized ||
    !normalized.includes("@") ||
    !normalized.includes(".")
  ) {
    throw new Error(
      "Digite um e-mail válido"
    );
  }

  const now = Date.now();

  db.emailCodes =
    db.emailCodes.filter(item => {
      return (
        item.email !== normalized ||
        item.expiresAt > now
      );
    });

  const code = makeCode();

  db.emailCodes.push({
    id: makeId("code"),
    email: normalized,
    code,
    createdAt: now,
    expiresAt: now + 10 * 60 * 1000,
    attempts: 0
  });

  saveDatabase(db);

  const result = await sendEmail(
    normalized,
    `${STORE_NAME} - Código de acesso`,
    `Seu código de acesso é: ${code}

Esse código expira em 10 minutos.

Se você não solicitou esse código, ignore esta mensagem.`
  );

  return {
    code,
    ...result
  };
}

function verifyEmailCode(
  email,
  code,
  db
) {
  const normalized = String(email || "")
    .trim()
    .toLowerCase();

  const typedCode = String(code || "")
    .trim();

  const item = [...db.emailCodes]
    .reverse()
    .find(x =>
      x.email === normalized
    );

  if (!item) {
    return {
      ok: false,
      error: "Código não encontrado"
    };
  }

  if (
    Date.now() >
    item.expiresAt
  ) {
    db.emailCodes =
      db.emailCodes.filter(
        x => x.id !== item.id
      );

    saveDatabase(db);

    return {
      ok: false,
      error: "Código expirado"
    };
  }

  item.attempts++;

  if (item.attempts > 5) {
    db.emailCodes =
      db.emailCodes.filter(
        x => x.id !== item.id
      );

    saveDatabase(db);

    return {
      ok: false,
      error: "Muitas tentativas"
    };
  }

  if (item.code !== typedCode) {
    saveDatabase(db);

    return {
      ok: false,
      error: "Código incorreto"
    };
  }

  db.emailCodes =
    db.emailCodes.filter(
      x => x.id !== item.id
    );

  let user = db.users.find(
    x => x.email === normalized
  );

  if (!user) {
    user = {
      id: makeId("usr"),
      email: normalized,
      name: normalized.split("@")[0],
      createdAt:
        new Date().toISOString()
    };

    db.users.push(user);
  }

  const sid = makeId("sess");

  db.sessions.push({
    id: sid,
    userId: user.id,
    createdAt: Date.now()
  });

  saveDatabase(db);

  return {
    ok: true,
    user,
    sid
  };
}

/* =========================================================
   SERVIDOR
   ========================================================= */

const server = http.createServer(
  async (req, res) => {
    try {
      if (req.method === "OPTIONS") {
        res.writeHead(204, CORS);
        return res.end();
      }

      const url = new URL(
        req.url,
        `http://${req.headers.host || "localhost"}`
      );

      const path = url.pathname;
      const db = database();

      /* HEALTH */

      if (
        path === "/api/health" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          ok: true,
          service: "Paozix API",
          version: "3.0.0",
          email: true,
          smtpConfigured: Boolean(
            process.env.SMTP_HOST &&
            process.env.SMTP_USER &&
            process.env.SMTP_PASS
          ),
          time:
            new Date().toISOString()
        });
      }

      /* CATÁLOGO */

      if (
        path === "/api/catalog" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          name: db.name,
          products: db.products,
          cid:
            process.env.GOOGLE_CLIENT_ID || ""
        });
      }

      /* PEDIR CÓDIGO */

      if (
        path === "/api/email/request" &&
        req.method === "POST"
      ) {
        const body =
          await readBody(req);

        try {
          const result =
            await requestEmailCode(
              body.email,
              db
            );

          return json(res, 200, {
            ok: true,
            message:
              "Código enviado",
            test: result.test
          });
        } catch (error) {
          console.error(error);

          return json(res, 400, {
            ok: false,
            error: error.message
          });
        }
      }

      /* CONFIRMAR CÓDIGO */

      if (
        path === "/api/email/verify" &&
        req.method === "POST"
      ) {
        const body =
          await readBody(req);

        const result =
          verifyEmailCode(
            body.email,
            body.code,
            db
          );

        if (!result.ok) {
          return json(res, 400, {
            ok: false,
            error: result.error
          });
        }

        setSessionCookie(
          res,
          result.sid
        );

        return json(res, 200, {
          ok: true,
          user:
            publicUser(result.user)
        });
      }

      /*
       /api/auth também envia código.
      */

      if (
        path === "/api/auth" &&
        req.method === "POST"
      ) {
        const body =
          await readBody(req);

        try {
          const result =
            await requestEmailCode(
              body.email,
              db
            );

          return json(res, 200, {
            ok: true,
            message:
              "Código enviado",
            test: result.test
          });
        } catch (error) {
          return json(res, 400, {
            ok: false,
            error: error.message
          });
        }
      }

      /* USUÁRIO */

      if (
        path === "/api/me" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          user:
            publicUser(
              getCurrentUser(req, db)
            )
        });
      }

      /* LOGOUT */

      if (
        path === "/api/logout" &&
        req.method === "POST"
      ) {
        const sid =
          getCookies(req).sid;

        db.sessions =
          db.sessions.filter(
            x => x.id !== sid
          );

        saveDatabase(db);

        setSessionCookie(
          res,
          "",
          -1
        );

        return json(res, 200, {
          ok: true
        });
      }

      /* PRODUTOS */

      if (
        path === "/api/products" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          products: db.products
        });
      }

      if (
        path === "/api/products" &&
        req.method === "POST"
      ) {
        const body =
          await readBody(req);

        const product = {
          id: makeId("prd"),
          ...body,
          createdAt:
            new Date().toISOString()
        };

        db.products.push(product);

        saveDatabase(db);

        return json(res, 201, {
          ok: true,
          product
        });
      }

      /* PEDIDO */

      if (
        path === "/api/order" &&
        req.method === "POST"
      ) {
        const user =
          getCurrentUser(req, db);

        if (!user) {
          return json(res, 401, {
            error:
              "Faça login primeiro"
          });
        }

        const body =
          await readBody(req);

        const order = {
          id: makeId("ord"),
          userId: user.id,
          ...body,
          status:
            body.status ||
            "pending",
          createdAt:
            new Date().toISOString()
        };

        db.orders.push(order);

        saveDatabase(db);

        return json(res, 200, {
          ok: true,
          order
        });
      }

      /* MINHA CONTA */

      if (
        path === "/api/my" &&
        req.method === "GET"
      ) {
        const user =
          getCurrentUser(req, db);

        if (!user) {
          return json(res, 401, {
            error:
              "Não autenticado"
          });
        }

        return json(res, 200, {
          orders:
            db.orders.filter(
              x =>
                x.userId === user.id
            ),

          reviews:
            db.reviews.filter(
              x =>
                x.userId === user.id
            ),

          tickets:
            db.tickets.filter(
              x =>
                x.userId === user.id
            )
        });
      }

      /* AVALIAÇÃO */

      if (
        path === "/api/review" &&
        req.method === "POST"
      ) {
        const user =
          getCurrentUser(req, db);

        if (!user) {
          return json(res, 401, {
            error:
              "Faça login primeiro"
          });
        }

        const body =
          await readBody(req);

        const review = {
          id: makeId("rev"),
          userId: user.id,
          ...body,
          createdAt:
            new Date().toISOString()
        };

        db.reviews.push(review);

        saveDatabase(db);

        return json(res, 200, {
          ok: true,
          review
        });
      }

      /* TICKET */

      if (
        path === "/api/ticket" &&
        req.method === "POST"
      ) {
        const user =
          getCurrentUser(req, db);

        if (!user) {
          return json(res, 401, {
            error:
              "Faça login primeiro"
          });
        }

        const body =
          await readBody(req);

        const ticket = {
          id: makeId("tic"),
          userId: user.id,
          ...body,
          status: "open",
          createdAt:
            new Date().toISOString()
        };

        db.tickets.push(ticket);

        saveDatabase(db);

        return json(res, 200, {
          ok: true,
          ticket
        });
      }

      /* ADMIN */

      if (
        path === "/api/admin/stats" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          users:
            db.users.length,
          products:
            db.products.length,
          orders:
            db.orders.length,
          reviews:
            db.reviews.length,
          tickets:
            db.tickets.length
        });
      }

      if (
        path === "/api/admin/users" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          users:
            db.users.map(
              publicUser
            )
        });
      }

      if (
        path === "/api/admin/orders" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          orders:
            db.orders
        });
      }

      if (
        path === "/api/admin/reviews" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          reviews:
            db.reviews
        });
      }

      if (
        path === "/api/admin/tickets" &&
        req.method === "GET"
      ) {
        return json(res, 200, {
          tickets:
            db.tickets
        });
      }

      /* API */

      if (path === "/api") {
        return json(res, 200, {
          ok: true,
          service:
            "Paozix API",

          endpoints: [
            "/api/health",
            "/api/catalog",
            "/api/auth",
            "/api/email/request",
            "/api/email/verify",
            "/api/me",
            "/api/logout",
            "/api/products",
            "/api/order",
            "/api/my",
            "/api/review",
            "/api/ticket"
          ]
        });
      }

      /* RAIZ */

      if (path === "/") {
        res.writeHead(200, {
          "Content-Type":
            "text/plain; charset=utf-8"
        });

        return res.end(
          "Paozix API online"
        );
      }

      return json(res, 404, {
        ok: false,
        error:
          "Rota não encontrada",
        path
      });

    } catch (error) {
      console.error(
        "ERRO:",
        error
      );

      return json(res, 500, {
        ok: false,
        error:
          "Erro interno do servidor"
      });
    }
  }
);

server.listen(
  PORT,
  HOST,
  () => {
    console.log("");
    console.log(
      "=============================="
    );
    console.log(
      "       PAOZIX API ONLINE"
    );
    console.log(
      "=============================="
    );
    console.log(
      "Porta:",
      PORT
    );
    console.log(
      "E-mail:",
      "ATIVADO"
    );
    console.log(
      "SMTP:",
      process.env.SMTP_HOST
        ? "CONFIGURADO"
        : "NÃO CONFIGURADO"
    );
    console.log(
      "=============================="
    );
    console.log("");
  }
);